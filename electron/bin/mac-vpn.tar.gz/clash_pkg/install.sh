#!/bin/bash
set -e

echo "[*] 开始部署 Clash TUN 锁死环境..."

# 移动二进制文件并赋权
sudo mkdir -p /usr/local/bin
sudo cp ./clash /usr/local/bin/clash
sudo chmod +x /usr/local/bin/clash

# 移动配置文件并锁死权限（禁止普通用户增删/修改订阅）
sudo mkdir -p "/Library/Application Support/Clash"
sudo cp ./config.yaml "/Library/Application Support/Clash/config.yaml"
sudo chown -R root:wheel "/Library/Application Support/Clash"
sudo chmod 755 "/Library/Application Support/Clash"
sudo chmod 644 "/Library/Application Support/Clash/config.yaml"

# 部署 LaunchDaemon 系统服务
sudo cp ./com.clash.tun.plist /Library/LaunchDaemons/com.clash.tun.plist
sudo chown root:wheel /Library/LaunchDaemons/com.clash.tun.plist
sudo chmod 644 /Library/LaunchDaemons/com.clash.tun.plist

# 加载服务
sudo launchctl unload /Library/LaunchDaemons/com.clash.tun.plist 2>/dev/null || true
sudo launchctl load -w /Library/LaunchDaemons/com.clash.tun.plist

echo "[+] 部署完成！TUN 模式已启动，配置文件已成功锁死。"
